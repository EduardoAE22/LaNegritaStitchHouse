// login.js

const SUPABASE_URL = 'https://wcpyvpvyoqmrukmvqfwt.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndjcHl2cHZ5b3FtcnVrbXZxZnd0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQxMTc4MDYsImV4cCI6MjA3OTY5MzgwNn0.EeFMe4x3A0R9wFsmv11R6ru2bqHS_00W5C38x2jgFio';

const client = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const form = document.getElementById('auth-form');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const submitBtn = document.getElementById('submit-btn');
const signupBtn = document.getElementById('signup-btn');
const forgotBtn = document.getElementById('forgot-btn');
const msg = document.getElementById('msg');

function setMessage(text, isError = false) {
  msg.textContent = text;
  msg.classList.toggle('error', isError);
}

// LOGIN
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  setMessage('');
  submitBtn.disabled = true;

  const email = emailInput.value.trim();
  const password = passwordInput.value;

  if (!email || !password) {
    setMessage('Completa correo y contraseña.', true);
    submitBtn.disabled = false;
    return;
  }

  const { error } = await client.auth.signInWithPassword({
    email,
    password,
  });

  if (error) {
    setMessage(error.message || 'No se pudo iniciar sesión.', true);
    submitBtn.disabled = false;
    return;
  }

  setMessage('Sesión iniciada, redirigiendo...');
  window.location.href = 'index.html';
});

// SIGNUP
signupBtn.addEventListener('click', async () => {
  setMessage('');
  submitBtn.disabled = true;
  signupBtn.disabled = true;

  const email = emailInput.value.trim();
  const password = passwordInput.value;

  if (!email || !password) {
    setMessage('Escribe correo y contraseña para crear tu cuenta.', true);
    submitBtn.disabled = false;
    signupBtn.disabled = false;
    return;
  }

  const { error } = await client.auth.signUp({
    email,
    password,
  });

  if (error) {
    setMessage(error.message || 'No se pudo crear la cuenta.', true);
    submitBtn.disabled = false;
    signupBtn.disabled = false;
    return;
  }

  setMessage('Cuenta creada. Revisa tu correo para confirmar.', false);
  submitBtn.disabled = false;
  signupBtn.disabled = false;
});

// RESET PASSWORD
if (forgotBtn) {
  forgotBtn.addEventListener('click', async () => {
    setMessage('');
    const email = emailInput.value.trim();

    if (!email) {
      setMessage('Escribe tu correo para enviarte el enlace de recuperación.', true);
      return;
    }

    setMessage('Enviando enlace de recuperación...');
    const redirectTo = window.location.origin + '/reset.html';

    const { error } = await client.auth.resetPasswordForEmail(email, {
      redirectTo,
    });

    if (error) {
      setMessage(error.message || 'No se pudo enviar el correo de recuperación.', true);
      return;
    }

    setMessage('Te enviamos un correo con el enlace para restablecer tu contraseña.');
  });
}

// (async () => {
//   const { data } = await client.auth.getSession();
//   if (data?.session) {
//     window.location.href = 'index.html';
//   }
// })();
