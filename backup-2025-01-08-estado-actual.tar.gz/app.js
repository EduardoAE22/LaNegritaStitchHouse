// app.js

// Config
const WHATSAPP_NUMBER = '529381952228';
const CART_STORAGE_KEY = 'ln_cart';
const SUPABASE_URL = window.__SUPABASE_URL || 'https://wcpyvpvyoqmrukmvqfwt.supabase.co';
const SUPABASE_ANON_KEY =
  window.__SUPABASE_ANON_KEY ||
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndjcHl2cHZ5b3FtcnVrbXZxZnd0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQxMTc4MDYsImV4cCI6MjA3OTY5MzgwNn0.EeFMe4x3A0R9wFsmv11R6ru2bqHS_00W5C38x2jgFio';
const SUPABASE_BUCKET = 'products';
const ADMIN_EMAILS = ['acostasolutions.dev@gmail.com'];

// Estado
let products = [];
let cart = [];
let activeCategory = 'all';
let supabaseClient = null;
let currentUser = null;
let isAdmin = false;

// DOM
const productsGrid = document.getElementById('products-grid');
const productsFeedback = document.getElementById('products-feedback');
const filterButtonsContainer = document.getElementById('filter-buttons');

const cartBtn = document.getElementById('cart-btn');
const cartCount = document.getElementById('cart-count');
const cartPanel = document.getElementById('cart-panel');
const cartOverlay = document.getElementById('cart-overlay');
const closeCartBtn = document.getElementById('close-cart');
const cartItemsContainer = document.getElementById('cart-items');
const cartTotalEl = document.getElementById('cart-total');
const cartWhatsappBtn = document.getElementById('cart-whatsapp');

const menuToggle = document.getElementById('menu-toggle');
const headerNav = document.querySelector('.header__nav');
const menuOverlay = document.getElementById('menu-overlay');

const adminBtn = document.getElementById('admin-btn');
const catAddBtn = document.getElementById('cat-add-btn');
const catEditBtn = document.getElementById('cat-edit-btn');
const catDeleteBtn = document.getElementById('cat-delete-btn');

// Admin form DOM
const adminPanel = document.getElementById('admin-panel');
const adminForm = document.getElementById('admin-form');
const inputId = document.getElementById('product-id');
const inputNombre = document.getElementById('product-nombre');
const inputPrecio = document.getElementById('product-precio');
const inputDescripcion = document.getElementById('product-descripcion');
const inputCategoria = document.getElementById('product-categoria');
const inputImagen = document.getElementById('product-imagen');
const adminStatus = document.getElementById('admin-status');
const adminResetBtn = document.getElementById('admin-reset');

// Inicializar Supabase client
supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
// Exponer en window para depurar
window.supabaseClient = supabaseClient;

// Utils
function normalizeEmail(email) {
  return (email || '').trim().toLowerCase();
}

function userIsAdmin(user) {
  if (!user) return false;
  const email = normalizeEmail(user.email);
  const role = user.app_metadata?.role;
  const allowList = ADMIN_EMAILS.map(normalizeEmail);
  return allowList.includes(email) || role === 'superadmin';
}

// =========================
// SESIÓN / AUTH
// =========================

async function ensureSession() {
  const { data, error } = await supabaseClient.auth.getSession();
  if (error) {
    console.error('Error verificando sesión', error);
  }

  const session = data?.session || null;
  currentUser = session?.user || null;
  isAdmin = userIsAdmin(currentUser);
  console.log('ensureSession → user:', currentUser?.email, 'isAdmin:', isAdmin);
  updateAdminUI();
  // NO redirigimos aquí: la tienda es pública
  return session;
}

function updateAdminUI() {
  if (adminPanel) {
    adminPanel.classList.toggle('is-visible', isAdmin);
    adminStatus.textContent = isAdmin
      ? 'Admin activo'
      : 'Acceso solo para administradores autorizados';
  }

  if (adminBtn) {
    adminBtn.textContent = isAdmin ? 'Cerrar sesión' : 'Admin';
  }

  const showCatActions = isAdmin && catAddBtn && catEditBtn && catDeleteBtn;
  if (showCatActions) {
    catAddBtn.style.display = 'inline-flex';
    catEditBtn.style.display = 'inline-flex';
    catDeleteBtn.style.display = 'inline-flex';
  } else {
    if (catAddBtn) catAddBtn.style.display = 'none';
    if (catEditBtn) catEditBtn.style.display = 'none';
    if (catDeleteBtn) catDeleteBtn.style.display = 'none';
  }
}

function handleLogoutButton() {
  console.log('LOGOUT: limpiando sesión y redirigiendo a login.html');

  // Fire-and-forget signOut
  try {
    if (supabaseClient?.auth) {
      supabaseClient.auth
        .signOut()
        .then(() => console.log('Supabase signOut OK'))
        .catch((err) => console.warn('Error en signOut (ignorado):', err));
    }
  } catch (e) {
    console.warn('Error sincrónico en signOut (ignorado):', e);
  }

  // Limpiar claves de Supabase en localStorage
  try {
    Object.keys(localStorage).forEach((key) => {
      if (key.startsWith('sb-')) {
        localStorage.removeItem(key);
      }
    });
    // Si quieres limpiar carrito también:
    // localStorage.removeItem(CART_STORAGE_KEY);
  } catch (e) {
    console.warn('Error limpiando localStorage (ignorado):', e);
  }

  currentUser = null;
  isAdmin = false;
  updateAdminUI();

  window.location.assign('login.html');
}
window.handleLogoutButton = handleLogoutButton;

function handleAdminButton() {
  console.log('Admin → forzar cierre de sesión');
  handleLogoutButton();
}
// Acciones de categorías (placeholder)
function handleCatAdd() {
  alert('Agregar nueva categoría: función próximamente.');
}
function handleCatEdit() {
  alert('Editar categoría: función próximamente.');
}
function handleCatDelete() {
  alert('Eliminar categoría: función próximamente.');
}

// =========================
// PRODUCTOS
// =========================

async function loadProducts() {
  setProductsFeedback('Cargando catálogo...', false);

  try {
    console.log('[loadProducts] iniciando consulta REST…');

    const url =
      `${SUPABASE_URL}/rest/v1/products` +
      '?select=id,nombre,precio,categoria,descripcion,imagen_url' +
      '&order=nombre.asc';

    const res = await fetch(url, {
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json'
      }
    });

    if (!res.ok) {
      const text = await res.text();
      console.error('[loadProducts] error HTTP', res.status, text);
      throw new Error(`Supabase respondió ${res.status}`);
    }

    const data = await res.json();
    console.log('[loadProducts] datos recibidos →', data);

    products = (data || []).map((p) => ({
      id: p.id,
      nombre: p.nombre,
      precio: p.precio,
      descripcion: p.descripcion,
      categoria: p.categoria,
      imagen: p.imagen_url || ''
    }));

    buildFilters(products);
    renderProducts();

    setProductsFeedback(
      products.length ? '' : 'Aún no hay productos cargados.',
      false
    );
  } catch (err) {
    console.error('Error cargando productos:', err);
    setProductsFeedback(
      'No se pudieron cargar los productos desde Supabase. Revisa tu conexión o las credenciales.',
      true
    );
  }
}

function setProductsFeedback(message, isError = false) {
  productsFeedback.textContent = message;
  productsFeedback.classList.toggle('products-feedback--error', !!isError);
}

function buildFilters(list) {
  const categories = Array.from(new Set(list.map((p) => p.categoria).filter(Boolean)));
  const allCats = ['all', ...categories];
  filterButtonsContainer.innerHTML = '';
  allCats.forEach((cat) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'filter-btn';
    btn.textContent = cat === 'all' ? 'Todos' : cat.charAt(0).toUpperCase() + cat.slice(1);
    btn.dataset.cat = cat;
    btn.classList.toggle('is-active', activeCategory === cat);
    btn.addEventListener('click', () => {
      activeCategory = cat;
      document.querySelectorAll('.filter-btn').forEach((b) => b.classList.remove('is-active'));
      btn.classList.add('is-active');
      renderProducts();
    });
    filterButtonsContainer.appendChild(btn);
  });
}

function renderProducts() {
  productsGrid.innerHTML = '';

  const visible =
    activeCategory === 'all'
      ? products
      : products.filter((product) => product.categoria === activeCategory);

  if (!products.length) {
    setProductsFeedback('Aún no hay productos cargados.', false);
    return;
  }

  if (!visible.length) {
    setProductsFeedback('No hay productos en esta categoría.', false);
    return;
  }

  setProductsFeedback('', false);

  visible.forEach((product) => {
    const card = document.createElement('article');
    card.className = 'product-card';

    const imgBtn = document.createElement('button');
    imgBtn.type = 'button';
    imgBtn.className = 'product-card__image-btn';
    imgBtn.dataset.id = product.id;

    if (!isAdmin) {
      imgBtn.classList.add('disabled');
    }

    if (product.imagen) {
      const img = document.createElement('img');
      img.src = product.imagen;
      img.alt = product.nombre;
      imgBtn.appendChild(img);
    } else {
      const placeholder = document.createElement('span');
      placeholder.className = 'product-card__image-placeholder';
      placeholder.textContent = isAdmin ? 'Añadir imagen' : 'Imagen pendiente';
      imgBtn.appendChild(placeholder);
    }

    if (isAdmin) {
      imgBtn.addEventListener('click', () => handleImageClick(product));
    }

    const body = document.createElement('div');
    body.className = 'product-card__body';

    const title = document.createElement('h3');
    title.textContent = product.nombre;

    const price = document.createElement('p');
    price.className = 'product-card__price';
    price.textContent = `$${product.precio} MXN`;

    const desc = document.createElement('p');
    desc.className = 'product-card__desc';
    desc.textContent = product.descripcion;

    const btnAdd = document.createElement('button');
    btnAdd.className = 'btn-primary btn-full';
    btnAdd.type = 'button';
    btnAdd.textContent = 'Agregar al carrito';
    btnAdd.addEventListener('click', () => addToCart(product));

    body.appendChild(title);
    body.appendChild(price);
    body.appendChild(desc);
    body.appendChild(btnAdd);

    if (isAdmin) {
      const editBtn = document.createElement('button');
      editBtn.className = 'btn-outline btn-full';
      editBtn.type = 'button';
      editBtn.textContent = 'Editar producto';
      editBtn.addEventListener('click', () => fillAdminForm(product));
      body.appendChild(editBtn);
    }

    card.appendChild(imgBtn);
    card.appendChild(body);
    productsGrid.appendChild(card);
  });

  renderCategoryItems();
}

// Imagen admin -> Storage
async function handleImageClick(product) {
  if (!isAdmin) {
    alert('Solo administradores autorizados pueden cambiar imágenes.');
    return;
  }

  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';

  input.addEventListener('change', async () => {
    const file = input.files[0];
    if (!file) return;

    try {
      const ext = file.name.split('.').pop();
      const filePath = `product-${product.id}-${Date.now()}.${ext || 'jpg'}`;

      const { error: uploadError } = await supabaseClient
        .storage
        .from(SUPABASE_BUCKET)
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: publicData } = supabaseClient.storage.from(SUPABASE_BUCKET).getPublicUrl(filePath);
      const publicUrl = publicData?.publicUrl || '';

      const { error: updateError } = await supabaseClient
        .from('products')
        .update({ imagen_url: publicUrl })
        .eq('id', product.id);

      if (updateError) throw updateError;

      product.imagen = publicUrl;
      renderProducts();
      alert('Imagen actualizada en Supabase.');
    } catch (err) {
      console.error('No se pudo subir la imagen', err);
      alert('No se pudo subir la imagen. Revisa permisos y bucket en Supabase.');
    }
  });

  input.click();
}

// =========================
// CARRITO
// =========================

function addToCart(product) {
  const existing = cart.find((item) => item.id === product.id);
  if (existing) {
    existing.cantidad += 1;
  } else {
    cart.push({
      id: product.id,
      nombre: product.nombre,
      precio: product.precio,
      cantidad: 1,
    });
  }
  updateCartBadge();
  renderCart();
  persistCart();
  openCart();
}

function updateCartBadge() {
  const totalItems = cart.reduce((sum, item) => sum + item.cantidad, 0);
  cartCount.textContent = totalItems;
}

function renderCart() {
  cartItemsContainer.innerHTML = '';

  if (cart.length === 0) {
    cartItemsContainer.textContent = 'Tu carrito está vacío.';
    cartTotalEl.textContent = '$0 MXN';
    return;
  }

  let total = 0;

  cart.forEach((item) => {
    const row = document.createElement('div');
    row.className = 'cart-item';

    const info = document.createElement('div');
    info.className = 'cart-item__info';
    info.innerHTML = `<strong>${item.nombre}</strong><br>$${item.precio} MXN c/u`;

    const qty = document.createElement('div');
    qty.className = 'cart-item__qty';

    const btnMinus = document.createElement('button');
    btnMinus.className = 'cart-item__btn';
    btnMinus.textContent = '-';
    btnMinus.addEventListener('click', () => changeQty(item.id, -1));

    const spanQty = document.createElement('span');
    spanQty.textContent = item.cantidad;

    const btnPlus = document.createElement('button');
    btnPlus.className = 'cart-item__btn';
    btnPlus.textContent = '+';
    btnPlus.addEventListener('click', () => changeQty(item.id, 1));

    qty.appendChild(btnMinus);
    qty.appendChild(spanQty);
    qty.appendChild(btnPlus);

    row.appendChild(info);
    row.appendChild(qty);
    cartItemsContainer.appendChild(row);

    total += item.precio * item.cantidad;
  });

  cartTotalEl.textContent = `$${total} MXN`;
}

function changeQty(id, delta) {
  const item = cart.find((i) => i.id === id);
  if (!item) return;

  item.cantidad += delta;
  if (item.cantidad <= 0) {
    cart = cart.filter((i) => i.id !== id);
  }

  updateCartBadge();
  renderCart();
  persistCart();
}

function renderCategoryItems() {
  const itemsLists = document.querySelectorAll('.category-items');
  if (!itemsLists.length) return;
  const groups = products.reduce((acc, p) => {
    const catKey = (p.categoria || '').toLowerCase();
    if (!catKey) return acc;
    acc[catKey] = acc[catKey] || [];
    acc[catKey].push(p);
    return acc;
  }, {});

  itemsLists.forEach(list => {
    const catName = (list.dataset.cat || '').toLowerCase();
    const listItems = groups[catName] || [];
    list.innerHTML = '';
    if (!listItems.length) {
      return;
    }
    listItems.forEach(p => {
      const li = document.createElement('li');
      li.textContent = p.nombre;
      list.appendChild(li);
    });
  });
}

function persistCart() {
  localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
}

function loadCartFromStorage() {
  const stored = localStorage.getItem(CART_STORAGE_KEY);
  if (!stored) return [];
  try {
    const parsed = JSON.parse(stored);
    if (Array.isArray(parsed)) {
      return parsed
        .map((item) => ({
          id: item.id,
          nombre: item.nombre,
          precio: item.precio,
          cantidad: item.cantidad,
        }))
        .filter((item) => item.id && item.cantidad > 0);
    }
  } catch (error) {
    console.warn('No se pudo leer el carrito guardado', error);
  }
  return [];
}

// =========================
// CARRITO UI
// =========================

function openCart() {
  cartPanel.classList.add('cart-panel--open');
  cartOverlay.classList.add('cart-overlay--open');
}

function closeCart() {
  cartPanel.classList.remove('cart-panel--open');
  cartOverlay.classList.remove('cart-overlay--open');
}

// WhatsApp
function sendCartToWhatsApp() {
  if (cart.length === 0) {
    const text = 'Hola, quiero más información sobre los productos de La Negrita Stitch House.';
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
    return;
  }

  let text = 'Hola, me gustaría hacer este pedido en La Negrita Stitch House:\n\n';
  cart.forEach((item) => {
    text += `• ${item.cantidad} x ${item.nombre} — ${item.precio} MXN c/u\n`;
  });
  const total = cart.reduce((sum, item) => sum + item.precio * item.cantidad, 0);
  text += `\nTotal aproximado: ${total} MXN\n`;
  text += '\n¿Me ayudas con la disponibilidad, tiempos y formas de pago, por favor?';

  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank');
}

// =========================
// MENÚ MÓVIL
// =========================

function toggleMenu() {
  const isOpen = headerNav.classList.toggle('is-open');
  menuOverlay.classList.toggle('menu-overlay--open', isOpen);
}

function closeMenu() {
  headerNav.classList.remove('is-open');
  menuOverlay.classList.remove('menu-overlay--open');
}

// =========================
// ADMIN FORM
// =========================

function fillAdminForm(product) {
  if (!adminForm || !isAdmin) return;
  inputId.value = product.id;
  inputNombre.value = product.nombre;
  inputPrecio.value = product.precio;
  inputDescripcion.value = product.descripcion;
  inputCategoria.value = product.categoria;
  adminStatus.textContent = `Editando ID ${product.id}`;
}

function resetAdminForm() {
  adminForm.reset();
  inputId.value = '';
  adminStatus.textContent = 'Crear nuevo producto';
}

async function handleAdminSubmit(e) {
  e.preventDefault();
  if (!isAdmin) {
    alert('Solo administradores pueden guardar productos.');
    return;
  }

  const formData = new FormData(adminForm);
  const payload = {
    nombre: formData.get('nombre')?.trim() || '',
    precio: Number(formData.get('precio')) || 0,
    descripcion: formData.get('descripcion')?.trim() || '',
    categoria: formData.get('categoria')?.trim() || ''
  };

  const file = formData.get('imagen');
  let imagenUrl = null;

  try {
    // 1) Si viene archivo, súbelo al bucket como ya hacías
    if (file && file.size > 0) {
      const ext = file.name.split('.').pop();
      const filePath = `product-${Date.now()}.${ext || 'jpg'}`;

      const { error: uploadError } = await supabaseClient
        .storage
        .from(SUPABASE_BUCKET)
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: publicData } = supabaseClient
        .storage
        .from(SUPABASE_BUCKET)
        .getPublicUrl(filePath);

      imagenUrl = publicData?.publicUrl || null;
    }

    const productId = formData.get('id');
    console.log('[admin] guardando producto →', {
      productId,
      ...payload,
      imagenUrl,
    });

    let dbError = null;

    if (productId) {
      // 2A) UPDATE con Supabase JS (usa tu sesión autenticada)
      const updatePayload = { ...payload };
      if (imagenUrl) updatePayload.imagen_url = imagenUrl;

      const { error } = await supabaseClient
        .from('products')
        .update(updatePayload)
        .eq('id', productId);

      dbError = error;
    } else {
      // 2B) INSERT con Supabase JS
      const insertPayload = { ...payload };
      if (imagenUrl) insertPayload.imagen_url = imagenUrl;

      const { error } = await supabaseClient
        .from('products')
        .insert(insertPayload);

      dbError = error;
    }

    if (dbError) {
      console.error('[admin] error guardando producto', dbError);
      alert(
        'No se pudo guardar el producto: ' +
          (dbError.message || 'revisa las políticas o datos.')
      );
      return;
    }

    alert(productId ? 'Producto actualizado.' : 'Producto creado.');
    resetAdminForm();
    await loadProducts();
  } catch (err) {
    console.error('Error guardando producto', err);
    alert('No se pudo guardar el producto. Revisa permisos y datos.');
  }
}


// =========================
// EVENTOS
// =========================

if (cartBtn) cartBtn.addEventListener('click', openCart);
if (closeCartBtn) closeCartBtn.addEventListener('click', closeCart);
if (cartOverlay) cartOverlay.addEventListener('click', closeCart);
if (cartWhatsappBtn) cartWhatsappBtn.addEventListener('click', sendCartToWhatsApp);

if (adminBtn) adminBtn.addEventListener('click', handleAdminButton);
if (catAddBtn) catAddBtn.addEventListener('click', handleCatAdd);
if (catEditBtn) catEditBtn.addEventListener('click', handleCatEdit);
if (catDeleteBtn) catDeleteBtn.addEventListener('click', handleCatDelete);

if (menuToggle) menuToggle.addEventListener('click', toggleMenu);
if (menuOverlay) menuOverlay.addEventListener('click', closeMenu);

if (adminForm) adminForm.addEventListener('submit', handleAdminSubmit);
if (adminResetBtn) adminResetBtn.addEventListener('click', resetAdminForm);

document.querySelectorAll('.header__nav a').forEach((link) =>
  link.addEventListener('click', closeMenu)
);
window.addEventListener('resize', () => {
  if (window.innerWidth > 768) closeMenu();
});

// =========================
// INICIALIZAR
// =========================

cart = loadCartFromStorage();
updateCartBadge();
renderCart();

supabaseClient.auth.onAuthStateChange(async (_event, session) => {
  currentUser = session?.user || null;
  isAdmin = userIsAdmin(currentUser);
  console.log('onAuthStateChange → user:', currentUser?.email, 'isAdmin:', isAdmin);
  updateAdminUI();
  await loadProducts();
});

(async () => {
  await ensureSession();
  await loadProducts();
})();

console.log('✅ app.js cargado correctamente');
